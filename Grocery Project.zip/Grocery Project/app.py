from flask import Flask, render_template, url_for, redirect, session, request, flash
from datetime import date, datetime, timedelta
from flask_sqlalchemy import SQLAlchemy
from fileinput import filename
from sqlalchemy.dialects.sqlite import DATETIME
from werkzeug.utils import secure_filename
from sqlalchemy import func
import decimal
import os

current_dir = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = 'static/'

# Allowed set of file format
ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg'])


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///" + \
    os.path.join(current_dir, "database.sqlite3")
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.app_context().push()


# session
app.secret_key = os.urandom(24)
db = SQLAlchemy(app)


class User(db.Model):
    __tablename__ = 'user'
    userid = db.Column('userid', db.Integer, primary_key=True)
    name = db.Column(db.String(40), nullable=False)
    email = db.Column(db.String(60), nullable=False)
    contact_no = db.Column(db.Integer)
    username = db.Column(db.String(30), nullable=False)
    userpwd = db.Column(db.String(20), nullable=False)
    address = db.Column(db.String(100))
    city = db.Column(db.String(30))
    pin = db.Column(db.Integer)

# Model for Manager table


class Manager(db.Model):
    __tablename__ = 'manager'
    managerId = db.Column('managerid', db.Integer, primary_key=True)
    adminame = db.Column(db.String(30), nullable=False)
    adminpwd = db.Column(db.String(20), nullable=False)


# Model for Category table


class Category(db.Model):
    __tablename__ = 'category'
    CategoryID = db.Column(db.Integer, primary_key=True)
    CategoryName = db.Column(db.String(100), nullable=False)
    products = db.relationship('Product', backref='category', uselist=True)

# Model for Product table


class Product(db.Model):
    __tablename__ = 'product'
    ProductID = db.Column(db.Integer, primary_key=True)
    ProductName = db.Column(db.String(100), unique=True, nullable=False)
    Expiry_date = db.Column(db.DateTime, nullable=False,
                            default=datetime.utcnow)
    Unit = db.Column(db.Text, nullable=False)
    Rate_per_unit = db.Column(db.Numeric, nullable=False)
    Quantity = db.Column(db.Numeric, nullable=False)
    # product_img = db.Column(db.Text, unique=True, nullable=False)
    CategoryID = db.Column(db.Integer, db.ForeignKey('category.CategoryID'))


class Mycart(db.Model):
    __tablename__ = 'mycart'
    ID = db.Column(db.Integer, primary_key=True)
    Productname = db.Column(db.String(100), nullable=False)
    Categoryname = db.Column(db.String(100), nullable=False)
    Unit = db.Column(db.Text, nullable=False)
    Rate_per_unit = db.Column(db.Numeric, nullable=False)
    Quantity = db.Column(db.Numeric, nullable=False)
    Totalamt = db.Column(db.Numeric, nullable=False)


@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html')


@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        loginid = request.form.get("LoginID")
        loginpwd = request.form.get("password")
        if request.form.get("Admin") == "Admin":
            manager = Manager.query.filter_by(adminame=loginid).first()
            if manager == None:
                print("Login and password invalid")
                flash("Don't have admin access", "danger")
            else:
                if (manager.adminame == loginid and
                        manager.adminpwd == loginpwd):
                    session["LoginID"] = manager.adminame
                    print("Suceessfully logged in")
                    return redirect("adminpage")
        else:
            user = User.query.filter_by(username=loginid).first()
            print("i am in user profile")

            if user == None:
                print("You don't have account , create newone")
                flash("Don't have user account", "danger")

            else:
                if (user.username == loginid and
                        user.userpwd == loginpwd):
                    session["username"] = user.name
                    session['current_user'] = user.username
                    print("username", session["username"])
                    print("Suceessfully logged in")
                    return redirect("userprofile")
                else:
                    print("Incorrect user password ")
                    flash("Incorrect user name and password", "danger")

    return render_template('login.html')


@app.route('/signup', methods=['POST', 'GET'])
def signup():
    if request.method == 'POST':
        try:
            uname = request.form.get("name")
            email = request.form.get("email")
            contactno = int(request.form.get("contact_no"))
            address = request.form.get("address")
            city = request.form.get("city")
            pincode = int(request.form.get("pincode"))
            username = request.form.get("username")
            password = request.form.get("password")
            print("iam in signup")
            u1 = User(name=uname, email=email, contact_no=contactno,
                      username=username, userpwd=password, address=address,
                      city=city, pin=pincode)
            print("u1 data", u1)
            db.session.add(u1)
            db.session.commit()
            flash("Record Added  Successfully,Go to Login Page", "success")
        except:
            flash("Error in Insert Operation", "danger")
        finally:
            return redirect(url_for("login"))

    return render_template('signup.html')


@app.route('/contact')
def contact():
    return render_template('contact.html')


@app.route('/adminpage', methods=['POST', 'GET'])
def adminpage():
    category = [r.CategoryName for r in Category.query.all()]
    product = Product.query.all()
    if category == None:
        category = "No Category"
    if product == None:
        product = "No products"
    prodname = request.form.get('prod')

    print("prodnamebefore", prodname)

    if request.method == 'POST':

        action = request.form['action']
        prod1 = request.form.get('prod')
        c1 = list(action)
        categname = request.form.get('categ')
        categ = [r.CategoryID for r in Category.query.filter_by(
            CategoryName=action).all()]
        categname = [r.CategoryName for r in Category.query.filter_by(
            CategoryName=action).all()]

        category = categname
        if category == []:
            category.append("No category listed")
        print("categname before:", categname)
        print("action before ", action)
        if action == categname[0]:
            product = Product.query.filter_by(CategoryID=categ[0]).all()
            catid = categ[0]
            session['catid'] = catid
            prodid = [p.ProductName for p in Product.query.filter_by(
                CategoryID=categ[0]).all()]

            category = categname
            print("products", product)
            selectval = categ[0]
            if product == []:
                product.append('No product added')
            categoryid = catid
            session['selectval'] = selectval
            print("selectval", session['selectval'])

            return render_template('adminpage.html', categories=category, products=product, selectval=selectval)

        elif action == 'Actions':
            return redirect(url_for("productupdate"))
        elif action == 'Edit':
            return redirect(url_for("productupdate"))
        elif action == 'Delete':
            return redirect(url_for("productdelete"))

    return render_template('adminpage.html', categories=category, products=product)


@app.route('/catpage', methods=['POST', 'GET'])
def catpage():
    if request.method == 'POST':
        try:
            cname = request.form.get("catname")
            c1 = Category(CategoryName=cname)
            db.session.add(c1)
            db.session.commit()
            flash("Record Added Successfully into Category", "success")
        except:
            flash("Error in  customer Insert Operation", "danger")
        finally:
            return redirect(url_for("adminpage"))

    return redirect(url_for("adminpage"))


@app.route('/catupdate', methods=['POST', 'GET'])
def catupdate():
    if request.method == 'POST':
        print(session['selectval'], "sectionvalue in cat")
        return redirect(url_for("adminpage"))


@app.route('/productpage', methods=['POST', 'GET'])
def productpage():

    if request.method == 'POST':
        try:
            print("session['catid']", session['catid'])
            pname = request.form.get("prodname1")
            unit = request.form.get("unit")
            rate = request.form.get("rate")
            quantity = request.form.get("quantity")
            expiredate = request.form.get("expiredate")
            expirydate = datetime.strptime(expiredate, '%Y-%m-%d').date()
            p1 = Product(ProductName=pname, Expiry_date=expirydate, Unit=unit,
                         Rate_per_unit=rate, Quantity=quantity,
                         CategoryID=session['selectval'])

            db.session.add(p1)
            db.session.commit()
            flash("Record Added Successfully into product", "success")

        except:
            flash("Error in  product Insert Operation", "danger")
        finally:
            return redirect(url_for("adminpage"))
    return redirect(url_for("adminpage"))


@app.route('/productupdate', methods=['POST', 'GET'])
def productupdate():
    value = request.args.get('values')
    session['value'] = value

    prod = Product.query.filter_by(ProductID=value).all()
    print("product:", prod)
    for prod1 in prod:
        prodid = prod1.ProductID
        prodname1 = prod1.ProductName
        print("prodname1", prodname1)
        unit = prod1.Unit
        rate = prod1.Rate_per_unit
        quantity = prod1.Quantity
        expiredt = str(prod1.Expiry_date)
        expiredate = expiredt[:10]
        categoryid = prod1.CategoryID
        session['categoryid'] = categoryid

    return render_template('adminupdate.html', prodid=prodid, prodname1=prodname1,
                           unit=unit, rate=rate, categoryid=categoryid, prod=prod,
                           quantity=quantity, expiredate=expiredate)


@app.route('/productedit', methods=['POST', 'GET'])
def productedit():
    print("inside product edit before ")
    if request.method == 'POST':
        try:

            prodname1 = request.form.get("prodname1")
            unit = request.form.get("unit")
            rate = request.form.get("rate")
            quantity = request.form.get("quantity")
            expiredt = request.form.get("expiredate")
            # expiredate = datetime.strptime(expiredt, '%y-%m-%d').date()
            # print("expiredate", expiredate)
            prod = Product.query.filter_by(
                ProductID=session['value']).first()
            prod.ProductName = prodname1
            prod.Unit = unit
            prod.Rate_per_unit = rate
            prod.Quantity = quantity

            print("expiredt", expiredt)
            print("prod.Expiry_date", prod.Expiry_date)
            expiredate = datetime.strptime(expiredt, '%Y-%m-%d').date()

            print("expiredate", expiredate)
            db.session.commit()
            flash("record updated successfully", "success")
        except:
            flash("error in update operation", "danger")
        finally:
            return redirect(url_for("adminpage"))

    return render_template('adminupdate.html', prodname1=prodname1,
                           unit=unit, rate=rate, quantity=quantity,
                           expiredate=expiredate)


@app.route('/productdelete', methods=['POST', 'GET'])
def productdelete():

    if request.method == 'POST':
        try:
            value = request.args.get('values')
            product = Product.query.filter_by(ProductID=value).delete()
            db.session.commit()
            flash("record deleted successfully", "success")
        except:
            flash("error in  product update operation", "danger")
        finally:
            return redirect(url_for("adminpage"))


@app.route('/logout')
def logout():
    print('Logout')
    return redirect(url_for("home"))


@app.route('/userprofile', methods=['POST', 'GET'])
def userprofile():
    current_user = session['current_user']
    if 'current_user' in session:
        print("user", current_user)
        category = Category.query.all()
        product = Product.query.all()
        if category == None:
            category = "No Category"
        if product == None:
            product = "No products"
        print("user before post")

        if request.method == 'POST':
            action = request.form['action']
            print("action", action)
            categ = Category.query.filter_by(CategoryName=action).first()
            if categ == None:
                categoryname = 'No category'
            else:
                categoryname = categ.CategoryName
                session['CategoryName'] = categ.CategoryName
                session['categoryid'] = categ.CategoryID
            # categname = request.form.get('categ')
            if action == categoryname:
                print("type of category", type(categ))
                print(categ, "category")

                # session['categoryid'] = categ.CategoryID
                # session['CategoryName'] = categ.CategoryName
                # categoryid = categ.CategoryID
                # categoryname = categ.CategoryName
                print("categoryname", categoryname)
                print("type of action", type(action))
                print("type categoryname", type(categoryname))
                print("i am in category action")
                product = Product.query.filter_by(
                    CategoryID=session['categoryid']).all()
                return render_template('userprofile.html',
                                       categoryname=categoryname, product=product)
            elif action == 'Buy':
                prodid = request.args.get('values')
                session['prodid'] = prodid
                print("prodid", prodid)
                product = Product.query.filter_by(ProductID=prodid).first()
                print("product.CategoryID", product.CategoryID)
                prodcatid = product.CategoryID
                if product.Quantity > 0:
                    availablity = "In Stock"
                else:
                    availablity = "out of Stock"

                category = Category.query.filter_by(
                    CategoryID=prodcatid).first()
                catname = category.CategoryName
                session['categid'] = catname

                print("Categpry", category)
                print("type category", type(category))

                return render_template('buy.html', prodid=prodid, product=product,
                                       catname=catname, availablity=availablity)
            elif action == 'Mycart':
                return redirect(url_for('Mycart'))
        return render_template('userprofile.html', category=category, product=product)
    else:
        return redirect(url_for('login'))


@app.route('/summary', methods=['POST', 'GET'])
def summary():
    category = Category.query.all()
    product = Product.query.all()
    return render_template('summary.html', category=category, product=product)


@app.route('/Cart', methods=['POST', 'GET'])
def Cart():
    mycart = Mycart.query.all()
    totalamt = 0
    for item in mycart:
        totalamt = totalamt + item.Totalamt
    if request.method == 'POST':
        mycart = Mycart.query.all().delete()
        db.session.commit()
        return redirect(url_for('userprofile'))

    return render_template('mycart.html', mycart=mycart, totalamt=totalamt)


@app.route('/Buy', methods=['POST', 'GET'])
def Buy():
    if request.method == 'POST':

        quantity = request.form.get('quantity')

        prod1 = Product.query.filter_by(ProductID=session['prodid']).first()

        print("prod1", prod1)
        prodname = prod1.ProductName
        print("prodname1", prodname)
        unit = prod1.Unit
        rate = prod1.Rate_per_unit
        total = decimal.Decimal(quantity) * decimal.Decimal(rate)
        categoryid = prod1.CategoryID
        category = Category.query.filter_by(CategoryID=categoryid).first()
        categoryname = category.CategoryName
        m1 = Mycart(Productname=prodname, Categoryname=categoryname, Unit=unit,
                    Rate_per_unit=rate, Quantity=quantity, Totalamt=total)
        db.session.add(m1)
        db.session.commit()
        return redirect(url_for('userprofile'))


if __name__ == '__main__':
    app.run(debug=True)
